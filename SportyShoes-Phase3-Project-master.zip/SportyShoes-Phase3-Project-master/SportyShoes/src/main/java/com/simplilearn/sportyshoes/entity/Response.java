package com.simplilearn.sportyshoes.entity;

public class Response {
	
	PurchaseEntity entity;
	private String type;
	
	public PurchaseEntity getEntity() {
		return entity;
	}
	public void setEntity(PurchaseEntity entity) {
		this.entity = entity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	


}
